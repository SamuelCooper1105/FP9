function updateDashboard() {
    fetch("/data")
        .then((response) => response.json())
        .then((data) => {
            document.getElementById("rpm").textContent = data.rpm;
            document.getElementById("coolant_temp").textContent = data.coolant_temp + " °F";
            document.getElementById("throttle").textContent = data.throttle + "%";
            document.getElementById("speed").textContent = data.speed + " MPH";
            document.getElementById("o2").textContent = data.o2;
            document.getElementById("map_val").textContent = data.map_val;
            document.getElementById("egr").textContent = data.egr;
            document.getElementById("step_count").textContent = data.step_count;
            document.getElementById("overdrive").textContent = data.overdrive;
            document.getElementById("malf").textContent = data.malf;
            document.getElementById("ref_pulse").textContent = data.ref_pulse;
            document.getElementById("aldl_mode").textContent = data.aldl_mode;
            document.getElementById("dia_pos").textContent = data.dia_pos;
            document.getElementById("aldl_pos").textContent = data.aldl_pos;
            document.getElementById("shigt_light").textContent = data.shigt_light;
            document.getElementById("high_bat_volt").textContent = data.high_bat_volt;
            document.getElementById("engine_load").textContent = data.engine_load + "%";
            document.getElementById("battery_status").textContent = data.battery_status;
            document.getElementById("coolant_status").textContent = data.coolant_status;
        });
}

setInterval(updateDashboard, 1000);
