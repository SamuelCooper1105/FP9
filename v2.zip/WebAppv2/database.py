
import sqlite3
from datetime import datetime
from pathlib import Path

DB_NAME = Path(__file__).resolve().parent / "telematics.db"


def setup_database():
    connection = sqlite3.connect(DB_NAME)
    cursor = connection.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS car_data (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            time TEXT,
            rpm INTEGER,
            coolant_temp INTEGER,
            throttle INTEGER,
            speed INTEGER,
            engine_load REAL,
            battery_status TEXT,
            coolant_status TEXT,
            oxygen REAL,
            bpclc INTEGER,
            malf INTEGER,
            egr REAL,
            step_count INTEGER,
            high_bat_volt INTEGER,
            overdrive INTEGER,
            ref_pulse INTEGER,
            aldl_mode INTEGER,
            dia_pos INTEGER,
            aldl_pos INTEGER,
            shigt_light INTEGER
        )
    """)
    connection.commit()
    connection.close()


def save_car_data(data):
    connection = sqlite3.connect(DB_NAME)
    cursor = connection.cursor()
    cursor.execute("""
        INSERT INTO car_data (
            time,
            rpm,
            coolant_temp,
            throttle,
            speed,
            engine_load,
            battery_status,
            coolant_status,
            oxygen,
            bpclc,
            malf,
            egr,
            step_count,
            high_bat_volt,
            overdrive,
            ref_pulse,
            aldl_mode,
            dia_pos,
            aldl_pos,
            shigt_light
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        data.get("rpm"),
        data.get("coolant_temp"),
        data.get("throttle"),
        data.get("speed"),
        data.get("engine_load"),
        data.get("battery_status"),
        data.get("coolant_status"),
        data.get("o2"),
        data.get("map_val"),
        data.get("malf"),
        data.get("egr"),
        data.get("step_count"),
        data.get("high_bat_volt"),
        data.get("overdrive"),
        data.get("ref_pulse"),
        data.get("aldl_mode"),
        data.get("dia_pos"),
        data.get("aldl_pos"),
        data.get("shigt_light"),
    ))

    connection.commit()
    connection.close()


def get_recent_data():
    connection = sqlite3.connect(DB_NAME)
    connection.row_factory = sqlite3.Row
    cursor = connection.cursor()
    cursor.execute("""
        SELECT * FROM car_data
        ORDER BY id DESC
        LIMIT 20
    """)
    rows = cursor.fetchall()
    connection.close()
    return rows


def get_trip_summary():
    connection = sqlite3.connect(DB_NAME)
    cursor = connection.cursor()
    cursor.execute("""
        SELECT
            COUNT(*) as total_records,
            ROUND(AVG(rpm), 1) as average_rpm,
            MAX(coolant_temp) as max_coolant,
            ROUND(AVG(high_bat_volt), 2) as avg_high_bat_bit,
            MAX(speed) as max_speed,
            ROUND(AVG(engine_load), 1) as average_engine_load
        FROM car_data
    """)

    summary = cursor.fetchone()
    connection.close()
    return summary
