from pathlib import Path

data_file = "output.txt"


def auto_convert(value):
    value = value.strip()
    try:
        num = float(value)
        return int(num) if num.is_integer() else num
    except ValueError:
        return value


def read_from_output_file():
    unmasked_data = {}
    with open(data_file, "r") as f:
        for line in f:
            key, value = line.split(":", 1)
            unmasked_data[key.strip()] = auto_convert(value)
    return unmasked_data


def get_car_data():
    data = read_from_output_file()
    if not data:
        return {}

    return {
        "coolant_temp": data.get("COOLANT_TEMP"),
        "speed": data.get("MPH"),
        "overdrive": data.get("OVERDRIVE"),
        "malf": data.get("MALF"),
        "rpm": data.get("RPM"),
        "throttle": data.get("THROTTLE_POS"),
        "o2": data.get("OXYGEN_SENSOR"),
        "map_val": data.get("BPCLC"),
        "egr": data.get("EGR_duty_cycle"),
        "step_count": data.get("step_count"),
        "ref_pulse": data.get("ref_pulse"),
        "aldl_mode": data.get("ALDL_mode"),
        "dia_pos": data.get("dia_pos"),
        "aldl_pos": data.get("aldl_pos"),
        "shigt_light": data.get("shigt_light"),
        "high_bat_volt": data.get("high_bat_volt"),
    }
